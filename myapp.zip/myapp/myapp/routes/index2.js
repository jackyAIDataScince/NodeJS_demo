var express = require('express');
  
var app = express();
var router = express.Router();

var mysql = require('mysql');

var db = mysql.createPool({
   host:'localhost',
   user: 'root',
   password:'password',
   database:'demo',
   debug: false
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/testconnect', function(req, res, next) {
  if (db != null) {
     res.send('connect success');
  } else {
     res.send('connect fail');
  }     
});

router.get('/select', function(req, res, next) {
  db.query('select * from tbl_book', function(err, rs) {
    res.render('select', { books:rs});
  });
});

// display add book page
router.get('/form', function(req, res, next) {    
    // render to add.ejs
    res.render('form', {
        book: '',
        price: ''        
    })
})

// Add
router.post('/form', function(req,res){
  console.log('Hello');
  db.serialize(()=>{
    db.run('INSERT INTO tbl_book(book,price) VALUES(?,?)', [req.body.book, req.body.price], function(err) {
      if (err) {
        return console.log(err.message);
      }
      console.log("New employee has been added");
      res.send("New employee has been added into the database with ID = "+req.body.book+ " and Name = "+req.body.price);
    });
  });
});

/* GET home page. */
//router.get('/form', function(req, res, next) {
//   res.render('form');
//});
 
//router.post('/form', function(req, res, next) {
// var book = req.body.book;
// var price = req.body.price;
 
// var sql = 'INSERT INTO tbl_book(book, price) VALUES ("Good","10")';
//   db.query(sql, function(err,rs) {
   // if (err) throw err;
//   res.redirect('form',{book:rs});
     
//  });
//});


router.get('/delete', function(req, res, next) {
  db.query('delete from tbl_book where id = ?',req.query.id , function(err, rs) {
    res.redirect('/select');
  });
});


router.get('/edit', function(req, res, next) {
  db.query('select * from tbl_book where id = ?',req.query.id , function(err, rs) {
    res.render('select', { books:rs});
  });
});

router.post('/edit', function(req, res, next) {
  var param = [
    req.body,
    req.query.id
 ]

 db.query('update tbl_book set ? where id = ?', param, function(err,rs) {
    res.render('edit',{book:rs});
 });
});

var server = app.listen(8002, function() {

 var host = server.address().address;

 var port = server.address().port;

console.log("Listening at http://%s:%s", host, port);

});

module.exports = router;

