var express = require('express');
var path   = require('path');  
var router = express.Router();
var app = express();
var logger = require('morgan');
var cookieParser = require('cookie-parser');

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

var mysql = require('mysql');

var db = mysql.createPool({
   host:'localhost',
   user: 'root',
   password:'password',
   database:'demo',
   debug: true
});

// GET home page. 
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

//Delete 
router.get('/delete', function(req, res, next) {
  db.query('delete from tbl_book where id = ?',req.query.id , function(err, rs) {
    res.redirect('/select');
  });
});

router.get('/testconnect', function(req, res, next) {
  if (db != null) {
     res.send('connect success');
  } else {
     res.send('connect fail');
  }     
});

router.get('/select', function(req, res, next) {
  db.query('select * from tbl_book', function(err, rs) {
    res.render('select', { books:rs});
  });
});

// GET home page. 
router.get('/form', function(req, res, next) {
   res.render('form');
});
 
router.post('/form', function(req, res, next) {
 var book = req.body.book;
 var price = req.body.price;
 
   var form_data = {
            book: book,
            price: price
        }
   db.query('INSERT INTO tbl_book SET ?', form_data, function(err, result) {
       if(!err){res.redirect('/select');}
       
   });
});

// Edit Page 
router.get('/edit', function(req, res, next) {
  db.query('select * from tbl_book where id = ?',req.query.id , function(err, rs) {
     res.render('edit',{books:rs});
  });
});

router.post('/edit', function(req, res, next) {
  var param = [
    req.body,           ///data for update
    req.query.id ]

    db.query('update tbl_book set ? where id = ?', param, function(err,rs) {
      if(!err) { res.render('select',{books:rs});}
    });
});

module.exports = router;

